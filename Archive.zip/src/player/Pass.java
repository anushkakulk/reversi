package player;

/**
 * A Function Object that indicates Passing, a type of move that a player can make.
 */
public class Pass implements IPlayerMove {

  /**
   * Creates a Pass Object.
   */
  public Pass() {
    // unsure at this point in time what should be in here, maybe nothing at all!
  }

}
